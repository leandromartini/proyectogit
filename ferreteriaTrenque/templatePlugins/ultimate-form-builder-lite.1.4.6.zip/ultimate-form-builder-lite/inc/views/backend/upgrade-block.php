<div class="ufbl-upgrade">
        <div class="ufbl-upgrade-top"><img src="<?php echo UFBL_IMG_DIR.'/upgrade/upgrade-top.png'?>"/></div>
        <div class="ufbl-upgrade-action-wrap">
          <a href="http://demo.accesspressthemes.com/wordpress-plugins/ultimate-form-builder/" target="_blank" title="Demo"><img src="<?php echo UFBL_IMG_DIR.'/upgrade/demo-btn.png'?>"/></a>
          <a href="https://accesspressthemes.com/wordpress-plugins/ultimate-form-builder/" target="_blank" title="Upgrade"><img src="<?php echo UFBL_IMG_DIR.'/upgrade/upgrade-btn.png'?>"/></a>
        </div>
        <div class="ufbl-upgrade-bottom"><img src="<?php echo UFBL_IMG_DIR.'/upgrade/upgrade-bottom.png'?>"/></div>
        <div class="ufbl-upgrade-action-wrap">
          <a href="http://demo.accesspressthemes.com/wordpress-plugins/ultimate-form-builder/" target="_blank" title="Demo"><img src="<?php echo UFBL_IMG_DIR.'/upgrade/demo-btn.png'?>"/></a>
          <a href="https://accesspressthemes.com/wordpress-plugins/ultimate-form-builder/" target="_blank" title="Upgrade"><img src="<?php echo UFBL_IMG_DIR.'/upgrade/upgrade-btn.png'?>"/></a>
        </div>
    </div>
    <div class="ufbl-clear"></div>