<?php
/**
 * Template part for displaying page content in page.php.
 *
 * @link https://codex.wordpress.org/Template_Hierarchy
 *
 * @package Eight_Sec
 */

?>

<article id="post-<?php the_ID(); ?>" <?php post_class(); ?>>
	<figure>
		<?php        
		if( has_post_thumbnail() ) : 
			the_post_thumbnail();
		endif;
		?>
	</figure>

	<div class="entry-content">
		<?php
			the_content();
		
			wp_link_pages( array(
				'before'      => '<div class="page-links"><span class="page-links-title">' . esc_html__( 'Pages:', 'eight-sec' ) . '</span>',
				'after'       => '</div>',
				'link_before' => '<span class="page-num-links">',
				'link_after'  => '</span>',
				) );
		?>
	</div><!-- .entry-content -->
	<?php 
	if(is_user_logged_in ()):
	?>
		<footer class="entry-footer">
			<?php
				edit_post_link(
					sprintf(
						/* translators: %s: Name of current post */
						esc_html__( 'Edit %s', 'eight-sec' ),
						the_title( '<span class="screen-reader-text">"', '"</span>', false )
					),
					'<span class="edit-link">',
					'</span>'
				);
			?>
		</footer><!-- .entry-footer -->
	<?php
	endif;
	?>
</article><!-- #post-## -->
